import os
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from analyzer import ResumeExtractor, ResumeAnalyzer
from ai_service import ai_service
from sample_data import SAMPLE_RESUME, SAMPLE_JOB_DESCRIPTION

app = FastAPI(
    title="AI Resume Analyzer & ATS Optimizer",
    description="Full-featured ATS resume analysis, skills gap matcher, and AI career assistant.",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request Models
class ChatRequest(BaseModel):
    message: str
    resume_text: Optional[str] = ""
    job_description: Optional[str] = ""
    history: Optional[List[Dict[str, str]]] = []
    gemini_key: Optional[str] = None
    openai_key: Optional[str] = None

class SettingsRequest(BaseModel):
    gemini_key: Optional[str] = None
    openai_key: Optional[str] = None

class DirectAnalyzeRequest(BaseModel):
    resume_text: str
    job_description: Optional[str] = ""


# Static Files Setup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
async def root():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "AI Resume Analyzer Backend Running. Open /static/index.html"}


@app.get("/api/sample")
async def get_sample():
    """Provides sample resume and job description for 1-click testing."""
    return {
        "resume": SAMPLE_RESUME.strip(),
        "job_description": SAMPLE_JOB_DESCRIPTION.strip()
    }


@app.get("/api/status")
async def get_system_status():
    """Returns AI model and system readiness status."""
    return ai_service.get_status()


@app.post("/api/settings")
async def update_settings(req: SettingsRequest):
    """Sets or updates API keys."""
    ai_service.set_keys(gemini_key=req.gemini_key, openai_key=req.openai_key)
    return {
        "status": "success",
        "message": "AI settings updated successfully",
        "current": ai_service.get_status()
    }


@app.post("/api/analyze")
async def analyze_resume_file(
    file: Optional[UploadFile] = File(None),
    resume_text: Optional[str] = Form(None),
    job_description: Optional[str] = Form("")
):
    """
    Analyzes an uploaded file (PDF, DOCX, TXT) or pasted resume text
    against an optional job description.
    """
    extracted_text = ""

    if file and file.filename:
        filename = file.filename.lower()
        contents = await file.read()

        if filename.endswith(".pdf"):
            extracted_text = ResumeExtractor.extract_from_pdf(contents)
        elif filename.endswith(".docx") or filename.endswith(".doc"):
            extracted_text = ResumeExtractor.extract_from_docx(contents)
        elif filename.endswith(".txt") or filename.endswith(".md"):
            extracted_text = ResumeExtractor.extract_from_text(contents)
        else:
            raise HTTPException(
                status_code=400,
                detail="Unsupported file format. Please upload a PDF, DOCX, or TXT file."
            )
    elif resume_text and resume_text.strip():
        extracted_text = resume_text.strip()
    else:
        raise HTTPException(
            status_code=400,
            detail="No resume provided. Please upload a document or paste text."
        )

    if not extracted_text or len(extracted_text.strip()) < 20:
        raise HTTPException(
            status_code=400,
            detail="Could not extract readable text from the document. Please ensure it is not a scanned image PDF."
        )

    # Perform analysis
    analyzer = ResumeAnalyzer(extracted_text, job_description)
    results = analyzer.calculate_ats_score()
    results["extracted_text"] = extracted_text

    return JSONResponse(content=results)


@app.post("/api/analyze-text")
async def analyze_resume_text(req: DirectAnalyzeRequest):
    """Direct JSON endpoint to analyze plain text."""
    if not req.resume_text or len(req.resume_text.strip()) < 20:
        raise HTTPException(status_code=400, detail="Resume text is too short or empty.")

    analyzer = ResumeAnalyzer(req.resume_text, req.job_description)
    results = analyzer.calculate_ats_score()
    results["extracted_text"] = req.resume_text
    return JSONResponse(content=results)


@app.post("/api/chat")
async def chat_with_assistant(req: ChatRequest):
    """
    AI Chatbot endpoint. Answers questions, rewrites bullet points,
    generates cover letters, and coaches candidates using the resume context.
    """
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    reply = await ai_service.chat(
        user_message=req.message,
        resume_text=req.resume_text or "",
        job_description=req.job_description or "",
        conversation_history=req.history or [],
        custom_gemini_key=req.gemini_key,
        custom_openai_key=req.openai_key
    )

    return {"reply": reply}


if __name__ == "__main__":
    import uvicorn
    print("\n" + "=" * 60)
    print("🚀 AI Resume Analyzer & ATS Optimizer is running at:")
    print("   👉 http://127.0.0.1:8000")
    print("=" * 60 + "\n")
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)