SAMPLE_RESUME = """Alex Rivera
San Francisco, CA | alex.rivera@example.com | (555) 234-5678
linkedin.com/in/alexrivera-tech | github.com/alexrivera-dev | alexrivera.dev

PROFESSIONAL SUMMARY
Dynamic and results-driven Senior Full Stack Software Engineer with 5+ years of experience architecting high-scale web platforms, distributed cloud microservices, and modern user experiences. Demonstrated expertise in Python, React, AWS, Docker, and PostgreSQL. Proven track record of boosting system performance by 40% and mentoring high-velocity engineering teams.

TECHNICAL SKILLS
- Languages: Python, JavaScript, TypeScript, SQL, HTML5, CSS3, Go
- Frameworks & Libraries: React, Node.js, FastAPI, Flask, Next.js, Express, Tailwind CSS, Redux
- Cloud & DevOps: AWS (EC2, S3, RDS, Lambda), Docker, Kubernetes, GitHub Actions, CI/CD, Terraform, Linux
- Databases & Tools: PostgreSQL, Redis, MongoDB, Git, Postman, Jira, Agile, System Design, Unit Testing

WORK EXPERIENCE
Senior Full Stack Engineer | Apex Cloud Solutions, San Francisco, CA
July 2022 - Present
- Architected and deployed microservices architecture handling 15M+ monthly API requests with 99.98% uptime using FastAPI, Docker, and AWS ECS.
- Spearheaded database query refactoring and Redis caching layer implementation, reducing p99 response latency by 45% and cutting AWS infrastructure costs by $18,000 annually.
- Mentored a cohort of 6 junior and mid-level software engineers, driving agile sprint velocity up by 25% and establishing automated CI/CD pipelines via GitHub Actions.
- Worked on frontend UI redesign using React and Tailwind CSS to modernize legacy internal management portals.

Full Stack Software Developer | Horizon Tech Labs, Austin, TX
August 2020 - June 2022
- Engineered responsive client-facing web applications using React, TypeScript, and Node.js, serving 80,000+ active enterprise users.
- Automated payment processing workflows with Stripe API and webhooks, reducing transaction failures by 30%.
- Responsible for writing unit and integration tests with PyTest and Jest, elevating code coverage from 55% to 88%.
- Assisted team with migrating monolithic backend services to containerized Docker services.

PROJECTS
- AI Document Intelligence Platform: Built full-stack document summarizer and search engine using Python, LangChain, FastAPI, and Next.js, adopted by 1,200+ beta users.
- Real-Time Collaborative Canvas: Developed WebSocket-driven collaborative workspace supporting real-time multi-user cursor tracking and state synchronization with Redis and React.

EDUCATION
Bachelor of Science in Computer Science
University of California, Berkeley | 2016 - 2020
- Dean's Honors List, President of Berkeley Coding Club

CERTIFICATIONS
- AWS Certified Solutions Architect - Associate (2023)
"""

SAMPLE_JOB_DESCRIPTION = """Role: Senior Full Stack Engineer / Technical Lead
Company: CloudScale Dynamics
Location: San Francisco, CA (Hybrid / Remote)

About the Role:
We are seeking an experienced Senior Full Stack Engineer to lead our core product engineering team. You will be responsible for building highly scalable cloud applications, designing resilient microservices, and delivering intuitive, high-performance web interfaces.

Key Responsibilities:
- Architect, build, and maintain production web services using Python (FastAPI/Django) and modern frontend frameworks (React/Next.js).
- Design and manage containerized cloud infrastructure on AWS utilizing Docker and Kubernetes (EKS).
- Optimize SQL queries, database indexing, and caching mechanisms using PostgreSQL and Redis.
- Collaborate with product managers, designers, and DevOps engineers in an agile environment.
- Champion engineering best practices, automated CI/CD pipelines, code reviews, and high test coverage.

Requirements:
- 4+ years of professional software development experience.
- Strong proficiency in Python, JavaScript/TypeScript, and React.
- Hands-on experience with AWS, Docker, Kubernetes, and modern CI/CD tools.
- Deep understanding of RESTful APIs, microservices architecture, and database design.
- Excellent communication, mentoring, and technical leadership skills.
"""
