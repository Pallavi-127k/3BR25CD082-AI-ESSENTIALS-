@echo off
title ResuMetrics AI - Resume Analyzer
echo =================================================================
echo   Starting ResuMetrics AI - ATS Resume Analyzer & Career Copilot
echo =================================================================
echo.
echo Opening browser to http://127.0.0.1:8000 ...
start http://127.0.0.1:8000
python main.py
pause
