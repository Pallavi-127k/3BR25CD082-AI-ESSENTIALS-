document.addEventListener('DOMContentLoaded', () => {
  // App State
  const state = {
    selectedFile: null,
    resumeText: '',
    jobDescription: '',
    currentAnalysis: null,
    chatHistory: [],
    geminiKey: localStorage.getItem('resumetrics_gemini_key') || '',
    openaiKey: localStorage.getItem('resumetrics_openai_key') || '',
    activeTab: 'file', // 'file' or 'text'
  };

  // DOM Elements - Navigation & Header
  const btnLoadSample = document.getElementById('btnLoadSample');
  const btnSampleHero = document.getElementById('btnSampleHero');
  const btnSettingsModal = document.getElementById('btnSettingsModal');
  const settingsModal = document.getElementById('settingsModal');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const geminiKeyInput = document.getElementById('geminiKeyInput');
  const openaiKeyInput = document.getElementById('openaiKeyInput');
  const aiStatusText = document.getElementById('aiStatusText');
  const chatEngineLabel = document.getElementById('chatEngineLabel');

  // DOM Elements - Input Section
  const tabUploadFile = document.getElementById('tabUploadFile');
  const tabPasteText = document.getElementById('tabPasteText');
  const dropzoneContainer = document.getElementById('dropzoneContainer');
  const fileInput = document.getElementById('fileInput');
  const browseFileBtn = document.getElementById('browseFileBtn');
  const selectedFileInfo = document.getElementById('selectedFileInfo');
  const selectedFileName = document.getElementById('selectedFileName');
  const selectedFileSize = document.getElementById('selectedFileSize');
  const removeFileBtn = document.getElementById('removeFileBtn');
  const textInputContainer = document.getElementById('textInputContainer');
  const resumeTextInput = document.getElementById('resumeTextInput');
  const jobDescInput = document.getElementById('jobDescInput');
  const jdToggleHeader = document.getElementById('jdToggleHeader');
  const jdBody = document.getElementById('jdBody');
  const jdChevron = document.getElementById('jdChevron');
  const btnAnalyze = document.getElementById('btnAnalyze');
  const analyzeSpinner = document.getElementById('analyzeSpinner');

  // DOM Elements - Results Section
  const emptyState = document.getElementById('emptyState');
  const resultsDashboard = document.getElementById('resultsDashboard');
  const gaugeBar = document.getElementById('gaugeBar');
  const atsScoreValue = document.getElementById('atsScoreValue');
  const scoreGradeBadge = document.getElementById('scoreGradeBadge');
  const wordCountBadge = document.getElementById('wordCountBadge');
  const verdictText = document.getElementById('verdictText');
  const verdictExplanation = document.getElementById('verdictExplanation');
  const kpiVerbs = document.getElementById('kpiVerbs');
  const kpiMetrics = document.getElementById('kpiMetrics');
  const kpiSkills = document.getElementById('kpiSkills');
  const kpiMatchRate = document.getElementById('kpiMatchRate');

  // DOM Elements - Breakdown Bars
  const scoreVerbs = document.getElementById('scoreVerbs');
  const barVerbs = document.getElementById('barVerbs');
  const scoreMetrics = document.getElementById('scoreMetrics');
  const barMetrics = document.getElementById('barMetrics');
  const scoreSkills = document.getElementById('scoreSkills');
  const barSkills = document.getElementById('barSkills');
  const scoreStructure = document.getElementById('scoreStructure');
  const barStructure = document.getElementById('barStructure');
  const scoreContact = document.getElementById('scoreContact');
  const barContact = document.getElementById('barContact');

  // DOM Elements - Tabs in Results
  const analysisTabBtns = document.querySelectorAll('.analysis-tab-btn');
  const analysisTabContents = document.querySelectorAll('.analysis-tab-content');
  const strengthsList = document.getElementById('strengthsList');
  const weaknessList = document.getElementById('weaknessList');
  const contactPillGrid = document.getElementById('contactPillGrid');
  const matchedSkillsCloud = document.getElementById('matchedSkillsCloud');
  const missingSkillsCloud = document.getElementById('missingSkillsCloud');
  const categorySkillsGrid = document.getElementById('categorySkillsGrid');
  const bulletCardsList = document.getElementById('bulletCardsList');
  const sectionsAccordion = document.getElementById('sectionsAccordion');

  // DOM Elements - AI Chatbot Copilot
  const aiChatDrawer = document.getElementById('aiChatDrawer');
  const btnToggleChat = document.getElementById('btnToggleChat');
  const btnCloseChat = document.getElementById('btnCloseChat');
  const btnClearChat = document.getElementById('btnClearChat');
  const chatMessages = document.getElementById('chatMessages');
  const chatForm = document.getElementById('chatForm');
  const chatInput = document.getElementById('chatInput');
  const promptChips = document.querySelectorAll('.prompt-chip');
  const toastContainer = document.getElementById('toastContainer');

  // Initialize
  initApp();

  function initApp() {
    setupEventListeners();
    loadStoredSettings();
    checkBackendStatus();
  }

  function setupEventListeners() {
    // Tab switching between file & text upload
    tabUploadFile.addEventListener('click', () => switchUploadMode('file'));
    tabPasteText.addEventListener('click', () => switchUploadMode('text'));

    // File Drag & Drop
    browseFileBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);

    dropzoneContainer.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzoneContainer.classList.add('dragover');
    });

    dropzoneContainer.addEventListener('dragleave', () => {
      dropzoneContainer.classList.remove('dragover');
    });

    dropzoneContainer.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzoneContainer.classList.remove('dragover');
      if (e.dataTransfer.files.length > 0) {
        setUploadedFile(e.dataTransfer.files[0]);
      }
    });

    removeFileBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      clearUploadedFile();
    });

    // Job Description Toggle
    jdToggleHeader.addEventListener('click', () => {
      jdBody.classList.toggle('hidden');
      jdChevron.style.transform = jdBody.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
    });

    // Sample data loaders
    btnLoadSample.addEventListener('click', loadSampleData);
    btnSampleHero.addEventListener('click', loadSampleData);

    // Settings Modal
    btnSettingsModal.addEventListener('click', () => {
      geminiKeyInput.value = state.geminiKey;
      openaiKeyInput.value = state.openaiKey;
      settingsModal.classList.remove('hidden');
    });

    btnCloseModal.addEventListener('click', () => {
      settingsModal.classList.add('hidden');
    });

    settingsModal.addEventListener('click', (e) => {
      if (e.target === settingsModal) {
        settingsModal.classList.add('hidden');
      }
    });

    btnSaveSettings.addEventListener('click', saveSettings);

    // Analyze Button
    btnAnalyze.addEventListener('click', handleAnalyze);

    // Analysis Sub-Tabs
    analysisTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-tab');
        analysisTabBtns.forEach(b => b.classList.remove('active'));
        analysisTabContents.forEach(c => c.classList.add('hidden'));

        btn.classList.add('active');
        const targetContent = document.getElementById(targetId);
        if (targetContent) {
          targetContent.classList.remove('hidden');
        }
      });
    });

    // Chatbot Drawer Controls
    btnToggleChat.addEventListener('click', () => {
      aiChatDrawer.classList.toggle('closed');
      if (!aiChatDrawer.classList.contains('closed')) {
        chatInput.focus();
      }
    });

    btnCloseChat.addEventListener('click', () => {
      aiChatDrawer.classList.add('closed');
    });

    btnClearChat.addEventListener('click', clearChat);

    chatForm.addEventListener('submit', handleChatSubmit);

    // Prompt Chips
    promptChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const prompt = chip.getAttribute('data-prompt');
        if (prompt) {
          if (aiChatDrawer.classList.contains('closed')) {
            aiChatDrawer.classList.remove('closed');
          }
          sendChatMessage(prompt);
        }
      });
    });
  }

  function switchUploadMode(mode) {
    state.activeTab = mode;
    if (mode === 'file') {
      tabUploadFile.classList.add('active');
      tabPasteText.classList.remove('active');
      dropzoneContainer.classList.remove('hidden');
      textInputContainer.classList.add('hidden');
    } else {
      tabUploadFile.classList.remove('active');
      tabPasteText.classList.add('active');
      dropzoneContainer.classList.add('hidden');
      textInputContainer.classList.remove('hidden');
    }
  }

  function handleFileSelect(e) {
    if (e.target.files.length > 0) {
      setUploadedFile(e.target.files[0]);
    }
  }

  function setUploadedFile(file) {
    state.selectedFile = file;
    selectedFileName.textContent = file.name;
    selectedFileSize.textContent = formatFileSize(file.size);
    selectedFileInfo.classList.remove('hidden');
    dropzoneContainer.querySelector('.dropzone-content').classList.add('hidden');
    showToast(`Loaded ${file.name}`, 'success');
  }

  function clearUploadedFile() {
    state.selectedFile = null;
    fileInput.value = '';
    selectedFileInfo.classList.add('hidden');
    dropzoneContainer.querySelector('.dropzone-content').classList.remove('hidden');
  }

  function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  }

  async function loadSampleData() {
    try {
      showToast('Loading sample resume...', 'info');
      const res = await fetch('/api/sample');
      if (!res.ok) throw new Error('Failed to load sample');
      const data = await res.json();

      switchUploadMode('text');
      resumeTextInput.value = data.resume;
      jobDescInput.value = data.job_description;

      if (jdBody.classList.contains('hidden')) {
        jdBody.classList.remove('hidden');
        jdChevron.style.transform = 'rotate(180deg)';
      }

      showToast('Sample resume & JD loaded! Starting ATS audit...', 'success');
      // Trigger analysis automatically
      handleAnalyze();
    } catch (err) {
      showToast(`Error loading sample: ${err.message}`, 'error');
    }
  }

  function loadStoredSettings() {
    if (state.geminiKey) {
      geminiKeyInput.value = state.geminiKey;
    }
    if (state.openaiKey) {
      openaiKeyInput.value = state.openaiKey;
    }
  }

  async function saveSettings() {
    state.geminiKey = geminiKeyInput.value.trim();
    state.openaiKey = openaiKeyInput.value.trim();

    localStorage.setItem('resumetrics_gemini_key', state.geminiKey);
    localStorage.setItem('resumetrics_openai_key', state.openaiKey);

    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gemini_key: state.geminiKey,
          openai_key: state.openaiKey
        })
      });
      showToast('AI Settings updated successfully', 'success');
      settingsModal.classList.add('hidden');
      checkBackendStatus();
    } catch (err) {
      showToast('Saved locally, but backend update failed.', 'warning');
    }
  }

  async function checkBackendStatus() {
    try {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data = await res.json();
        aiStatusText.textContent = data.mode;
        chatEngineLabel.textContent = `Online (${data.mode})`;
      }
    } catch (e) {
      aiStatusText.textContent = 'Backend Offline';
    }
  }

  async function handleAnalyze() {
    const jdText = jobDescInput.value.trim();
    state.jobDescription = jdText;

    let formData = new FormData();
    formData.append('job_description', jdText);

    if (state.activeTab === 'file') {
      if (!state.selectedFile) {
        showToast('Please select or drop a resume file first!', 'error');
        return;
      }
      formData.append('file', state.selectedFile);
    } else {
      const text = resumeTextInput.value.trim();
      if (!text || text.length < 30) {
        showToast('Please paste a valid resume with at least 30 characters.', 'error');
        return;
      }
      formData.append('resume_text', text);
      state.resumeText = text;
    }

    // Set UI loading state
    btnAnalyze.disabled = true;
    analyzeSpinner.classList.remove('hidden');

    try {
      showToast('Running comprehensive ATS scan...', 'info');
      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || 'Analysis failed');
      }

      const results = await response.json();
      state.currentAnalysis = results;
      if (results.extracted_text) {
        state.resumeText = results.extracted_text;
      }

      // Render Results
      renderResults(results);
      showToast('ATS Resume Audit complete!', 'success');

      // Scroll smoothly to results
      resultsDashboard.scrollIntoView({ behavior: 'smooth', block: 'start' });

      // Notify Chatbot with initial context
      notifyChatbotResumeLoaded(results);

    } catch (err) {
      showToast(`Error: ${err.message}`, 'error');
    } finally {
      btnAnalyze.disabled = false;
      analyzeSpinner.classList.add('hidden');
    }
  }

  function renderResults(data) {
    emptyState.classList.add('hidden');
    resultsDashboard.classList.remove('hidden');

    // 1. Gauge & Score
    const score = data.overall_score || 0;
    animateScoreGauge(score, data.grade_color);

    scoreGradeBadge.textContent = `${data.grade} (${score}/100)`;
    scoreGradeBadge.style.color = data.grade_color;
    scoreGradeBadge.style.borderColor = data.grade_color;
    scoreGradeBadge.style.backgroundColor = `${data.grade_color}1a`;

    wordCountBadge.textContent = `${data.word_count} Words (${data.word_count_status})`;
    verdictText.textContent = data.grade === 'Excellent' ? 'Top Tier ATS Candidate' : (data.grade === 'Good' ? 'Solid Resume Foundation' : 'Needs Optimization');
    verdictExplanation.textContent = data.verdict;

    // 2. KPIs
    const breakdown = data.breakdown || {};
    kpiVerbs.textContent = breakdown.impact_and_action_verbs?.verbs_found?.length || 0;
    kpiMetrics.textContent = breakdown.measurable_metrics?.metrics_count || 0;
    kpiSkills.textContent = data.total_skills_count || 0;
    kpiMatchRate.textContent = `${data.job_match?.match_rate || 75}%`;

    // 3. Category Breakdown Bars
    renderBar(scoreVerbs, barVerbs, breakdown.impact_and_action_verbs);
    renderBar(scoreMetrics, barMetrics, breakdown.measurable_metrics);
    renderBar(scoreSkills, barSkills, breakdown.skills_and_keywords);
    renderBar(scoreStructure, barStructure, breakdown.structure_and_formatting);
    renderBar(scoreContact, barContact, breakdown.contact_and_completeness);

    // 4. Strengths & Weaknesses
    renderFeedbackList(strengthsList, data.strengths || [], 'green');
    renderFeedbackList(weaknessList, data.weaknesses || [], 'amber');

    // 5. Contact Audit
    renderContactScan(data.contact_info);

    // 6. Skills Matrix
    renderSkillsMatrix(data);

    // 7. Bullet Points
    renderBulletPoints(data.bullet_analysis || []);

    // 8. Parsed Sections
    renderSections(data.sections || {});
  }

  function animateScoreGauge(targetScore, color) {
    const circumference = 440;
    const offset = circumference - (circumference * targetScore) / 100;
    gaugeBar.style.stroke = color;
    gaugeBar.style.strokeDashoffset = offset;

    // Counter animation
    let current = 0;
    const duration = 1200;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = targetScore / steps;

    const timer = setInterval(() => {
      current += increment;
      if (current >= targetScore) {
        atsScoreValue.textContent = targetScore;
        clearInterval(timer);
      } else {
        atsScoreValue.textContent = Math.floor(current);
      }
    }, stepTime);
  }

  function renderBar(textEl, fillEl, factor) {
    if (!factor) return;
    textEl.textContent = `${factor.score} / ${factor.max}`;
    fillEl.style.width = `${factor.percentage}%`;
  }

  function renderFeedbackList(container, items, theme) {
    container.innerHTML = '';
    container.className = `feedback-list ${theme}-bullets`;
    if (items.length === 0) {
      container.innerHTML = `<li>No significant issues detected in this category.</li>`;
      return;
    }
    items.forEach(text => {
      const li = document.createElement('li');
      li.textContent = text;
      container.appendChild(li);
    });
  }

  function renderContactScan(contact) {
    contactPillGrid.innerHTML = '';
    if (!contact) return;

    const items = [
      { label: 'Name', val: contact.name, icon: 'fa-user' },
      { label: 'Email', val: contact.email, icon: 'fa-envelope' },
      { label: 'Phone', val: contact.phone, icon: 'fa-phone' },
      { label: 'LinkedIn', val: contact.linkedin, icon: 'fa-brands fa-linkedin' },
      { label: 'GitHub', val: contact.github, icon: 'fa-brands fa-github' },
      { label: 'Portfolio', val: contact.portfolio, icon: 'fa-globe' }
    ];

    items.forEach(item => {
      const pill = document.createElement('div');
      const isValid = Boolean(item.val);
      pill.className = `contact-pill ${isValid ? 'valid' : 'missing'}`;
      pill.innerHTML = `
        <i class="${item.icon}"></i>
        <span><strong>${item.label}:</strong> ${isValid ? item.val : 'Not Detected'}</span>
      `;
      contactPillGrid.appendChild(pill);
    });
  }

  function renderSkillsMatrix(data) {
    const jm = data.job_match || {};
    matchedSkillsCloud.innerHTML = '';
    missingSkillsCloud.innerHTML = '';
    categorySkillsGrid.innerHTML = '';

    // Matched skills
    const matched = jm.matched_keywords || [];
    if (matched.length > 0) {
      matched.forEach(skill => {
        const tag = document.createElement('span');
        tag.className = 'skill-tag matched';
        tag.innerHTML = `<i class="fa-solid fa-check"></i> ${skill}`;
        matchedSkillsCloud.appendChild(tag);
      });
    } else {
      matchedSkillsCloud.innerHTML = `<span class="field-hint">Paste a Job Description to view matched requirements.</span>`;
    }

    // Missing skills
    const missing = jm.missing_keywords || [];
    if (missing.length > 0) {
      missing.forEach(skill => {
        const tag = document.createElement('span');
        tag.className = 'skill-tag missing';
        tag.innerHTML = `<i class="fa-solid fa-plus"></i> ${skill}`;
        tag.title = 'Click to ask AI assistant how to incorporate this skill';
        tag.style.cursor = 'pointer';
        tag.addEventListener('click', () => {
          if (aiChatDrawer.classList.contains('closed')) {
            aiChatDrawer.classList.remove('closed');
          }
          sendChatMessage(`How can I naturally incorporate the skill "${skill}" into my resume experience?`);
        });
        missingSkillsCloud.appendChild(tag);
      });
    } else {
      missingSkillsCloud.innerHTML = `<span class="field-hint">Great job! No major target skills are missing.</span>`;
    }

    // Categories
    const categories = data.extracted_skills || {};
    for (const [catName, skillList] of Object.entries(categories)) {
      if (skillList && skillList.length > 0) {
        const card = document.createElement('div');
        card.className = 'cat-skill-card';
        card.innerHTML = `
          <div class="cat-title">${catName} (${skillList.length})</div>
          <div class="skill-tags-cloud">
            ${skillList.map(s => `<span class="skill-tag neutral">${s}</span>`).join('')}
          </div>
        `;
        categorySkillsGrid.appendChild(card);
      }
    }
  }

  function renderBulletPoints(bullets) {
    bulletCardsList.innerHTML = '';
    if (bullets.length === 0) {
      bulletCardsList.innerHTML = `<p class="field-hint">No distinct bullet points found to rewrite.</p>`;
      return;
    }

    bullets.forEach((b, idx) => {
      const card = document.createElement('div');
      card.className = 'bullet-card';
      card.innerHTML = `
        <div class="bullet-critique">
          <i class="fa-solid fa-lightbulb"></i>
          <span><strong>Analysis:</strong> ${b.critique}</span>
        </div>
        <div class="bullet-compare-row">
          <div class="bullet-box before">
            <strong>Original:</strong><br/>
            ${b.original}
          </div>
          <div class="bullet-box after">
            <strong>High-Impact ATS Rewrite:</strong><br/>
            <span>${b.suggested_rewrite}</span>
            <button class="btn btn-secondary btn-copy-bullet" data-copy="${escapeHtml(b.suggested_rewrite)}">
              <i class="fa-regular fa-copy"></i> Copy
            </button>
          </div>
        </div>
      `;
      bulletCardsList.appendChild(card);
    });

    // Add copy listener
    document.querySelectorAll('.btn-copy-bullet').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.getAttribute('data-copy');
        navigator.clipboard.writeText(text);
        showToast('Rewritten bullet copied to clipboard!', 'success');
      });
    });
  }

  function renderSections(sections) {
    sectionsAccordion.innerHTML = '';
    for (const [secKey, content] of Object.entries(sections)) {
      if (!content || secKey === 'other') continue;
      const card = document.createElement('div');
      card.className = 'sec-card';
      card.innerHTML = `
        <div class="sec-header">
          <span><i class="fa-solid fa-folder-open"></i> ${secKey.toUpperCase()}</span>
          <i class="fa-solid fa-chevron-down"></i>
        </div>
        <div class="sec-content">${escapeHtml(content)}</div>
      `;
      sectionsAccordion.appendChild(card);
    }
  }

  // AI Chatbot Functions
  function notifyChatbotResumeLoaded(results) {
    const candidateName = results.contact_info?.name || 'Candidate';
    const score = results.overall_score || 0;
    const initialMsg = `🎯 I've loaded your resume for **${candidateName}** with an **ATS Score of ${score}/100** (${results.grade})! What would you like to improve first? Try the quick action buttons above or ask a specific question.`;

    appendChatMessage('assistant', initialMsg);
  }

  function appendChatMessage(role, content) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${role === 'user' ? 'user-msg' : 'bot-msg'}`;

    const icon = role === 'user' ? 'fa-user' : 'fa-robot';
    const parsedHtml = (typeof marked !== 'undefined') ? marked.parse(content) : escapeHtml(content);

    msgDiv.innerHTML = `
      <div class="msg-avatar"><i class="fa-solid ${icon}"></i></div>
      <div class="msg-bubble">${parsedHtml}</div>
    `;

    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Track history
    state.chatHistory.push({ role, content });
  }

  function handleChatSubmit(e) {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;
    chatInput.value = '';
    sendChatMessage(text);
  }

  async function sendChatMessage(message) {
    appendChatMessage('user', message);

    // Bot Typing Indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'chat-msg bot-msg';
    typingIndicator.id = 'typingIndicator';
    typingIndicator.innerHTML = `
      <div class="msg-avatar"><i class="fa-solid fa-robot"></i></div>
      <div class="msg-bubble" style="display:flex;gap:6px;align-items:center;">
        <span class="spinner" style="width:14px;height:14px;"></span>
        <span style="font-size:0.85rem;color:var(--text-muted);">Thinking...</span>
      </div>
    `;
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: message,
          resume_text: state.resumeText || (resumeTextInput ? resumeTextInput.value : ''),
          job_description: state.jobDescription || (jobDescInput ? jobDescInput.value : ''),
          history: state.chatHistory.slice(-8),
          gemini_key: state.geminiKey || null,
          openai_key: state.openaiKey || null
        })
      });

      // Remove typing indicator
      const ind = document.getElementById('typingIndicator');
      if (ind) ind.remove();

      if (!response.ok) {
        throw new Error('Chat service error');
      }

      const data = await response.json();
      appendChatMessage('assistant', data.reply);

    } catch (err) {
      const ind = document.getElementById('typingIndicator');
      if (ind) ind.remove();
      appendChatMessage('assistant', `⚠️ Sorry, I encountered an issue processing your request: ${err.message}`);
    }
  }

  function clearChat() {
    state.chatHistory = [];
    chatMessages.innerHTML = `
      <div class="chat-msg bot-msg">
        <div class="msg-avatar"><i class="fa-solid fa-robot"></i></div>
        <div class="msg-bubble">
          <p>Conversation reset. How can I assist you with your resume optimization today?</p>
        </div>
      </div>
    `;
    showToast('Chat history cleared', 'info');
  }

  // Toast Notification
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'fa-circle-info';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-circle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  function escapeHtml(text) {
    if (!text) return '';
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});
